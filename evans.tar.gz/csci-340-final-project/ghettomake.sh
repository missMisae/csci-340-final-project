#!/bin/bash
gcc cache_functions.c -o cacheshit && i=0; ./cacheshit;
