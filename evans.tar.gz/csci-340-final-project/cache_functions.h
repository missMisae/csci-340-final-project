long block_size();
long cache_size(double time_difference, int chunk_size);
double speed_main_memory();
double speed_cache_memory();
